'use strict';

// MINI GAME: GOOD CHOICE OR BAD CHOICE?
// Semua elemen diambil berdasarkan ID yang tersedia di index.html.

const quizQuestions = [
  {
    icon: '📚',
    question: 'Kamu sedang belajar, lalu notifikasi media sosial muncul. Apa yang kamu lakukan?',
    choices: [
      'Cek notifikasi sebentar, lalu lanjut belajar.',
      'Abaikan dulu dan selesaikan sesi belajar.'
    ],
    correct: 1,
    goodTitle: 'GOOD CHOICE! Fokusmu terjaga.',
    goodText: 'Kamu memilih menyelesaikan kegiatan yang penting terlebih dahulu. Notifikasi bisa diperiksa saat waktu istirahat.',
    badTitle: 'RED FLAG! Fokus bisa terganggu.',
    badText: 'Mengecek notifikasi dapat membuat perhatian teralihkan dan tugas tertunda. Coba aktifkan mode fokus saat belajar.'
  },
  {
    icon: '🌙',
    question: 'Sudah waktunya tidur, tetapi kamu masih ingin scrolling. Apa pilihanmu?',
    choices: [
      'Terus scrolling sampai mengantuk.',
      'Simpan HP dan mulai rutinitas tidur.'
    ],
    correct: 1,
    goodTitle: 'GOOD CHOICE! Istirahat itu penting.',
    goodText: 'Kamu memilih memberi jeda dari layar dan menjaga waktu istirahat. Pertahankan kebiasaan baik ini.',
    badTitle: 'RED FLAG! Waktu tidur tertunda.',
    badText: 'Scrolling tanpa batas bisa membuat waktu tidur semakin mundur. Coba letakkan HP sebelum waktu tidur.'
  },
  {
    icon: '🍽️',
    question: 'Kamu sedang makan bersama keluarga. Apa yang sebaiknya dilakukan?',
    choices: [
      'Letakkan HP dan ikut mengobrol.',
      'Tetap melihat video sambil makan.'
    ],
    correct: 0,
    goodTitle: 'GOOD CHOICE! Nikmati momen bersama.',
    goodText: 'Kamu memberi perhatian kepada orang-orang di sekitarmu. Waktu bersama keluarga juga penting.',
    badTitle: 'RED FLAG! Interaksi bisa terlewat.',
    badText: 'Terlalu fokus pada layar dapat membuatmu melewatkan obrolan dan momen bersama keluarga.'
  },
  {
    icon: '⏳',
    question: 'Kamu sadar sudah bermain HP jauh lebih lama dari rencana. Apa langkah terbaik?',
    choices: [
      'Lanjut saja, sudah terlanjur.',
      'Berhenti sejenak dan atur batas waktu.'
    ],
    correct: 1,
    goodTitle: 'GOOD CHOICE! Kamu mulai mengambil kendali.',
    goodText: 'Menyadari kebiasaan adalah langkah awal. Buat batas waktu yang realistis dan coba jalankan secara konsisten.',
    badTitle: 'RED FLAG! Waktu terus berlalu.',
    badText: 'Mengabaikan batas waktu bisa membuat kebiasaan sulit dikendalikan. Coba berhenti sejenak dan evaluasi penggunaan HP.'
  },
  {
    icon: '🏸',
    question: 'Akhir pekan tiba dan kamu punya waktu luang. Apa pilihan yang lebih seimbang?',
    choices: [
      'Menghabiskan seluruh waktu dengan HP.',
      'Membagi waktu untuk aktivitas offline dan online.'
    ],
    correct: 1,
    goodTitle: 'GOOD CHOICE! Seimbang itu keren.',
    goodText: 'Kamu tetap bisa menikmati teknologi sambil melakukan aktivitas lain seperti olahraga, membaca, atau bertemu teman.',
    badTitle: 'RED FLAG! Aktivitas lain bisa terlewat.',
    badText: 'Menghabiskan seluruh waktu di depan layar dapat membuat kesempatan bergerak, mencoba hobi, atau bertemu teman terlewat.'
  }
];

function getElement(id) {
  const element = document.getElementById(id);
  if (!element) {
    console.error(`Elemen dengan ID "${id}" tidak ditemukan. Periksa index.html.`);
  }
  return element;
}

const ui = {
  menuToggle: getElement('menuToggle'),
  nav: getElement('mainNav'),
  year: getElement('currentYear'),
  gamePanel: getElement('gamePanel'),
  gamePlay: getElement('gamePlay'),
  gameResult: getElement('gameResult'),
  questionCounter: getElement('questionCounter'),
  progressTrack: getElement('progressTrack'),
  progressBar: getElement('progressBar'),
  scenarioIcon: getElement('scenarioIcon'),
  scenarioQuestion: getElement('scenarioQuestion'),
  answerTextA: getElement('answerTextA'),
  answerTextB: getElement('answerTextB'),
  answerButtons: Array.from(document.querySelectorAll('.answer-button')),
  feedback: getElement('gameFeedback'),
  score: getElement('scoreDisplay'),
  nextButton: getElement('nextButton'),
  resultMedal: getElement('resultMedal'),
  resultTitle: getElement('resultTitle'),
  resultMessage: getElement('resultMessage'),
  finalScore: getElement('finalScore'),
  restartButton: getElement('restartButton')
};

let currentQuestionIndex = 0;
let totalScore = 0;
let hasAnswered = false;

function setText(element, value) {
  if (element) element.textContent = value;
}

function renderQuestion() {
  const question = quizQuestions[currentQuestionIndex];
  if (!question) return;

  hasAnswered = false;
  ui.gamePlay.hidden = false;
  ui.gameResult.hidden = true;

  setText(ui.questionCounter, `PERTANYAAN ${currentQuestionIndex + 1} / ${quizQuestions.length}`);
  setText(ui.scenarioIcon, question.icon);
  setText(ui.scenarioQuestion, question.question);
  setText(ui.answerTextA, question.choices[0]);
  setText(ui.answerTextB, question.choices[1]);
  setText(ui.score, `SKOR: ${totalScore}`);

  const progressPercent = ((currentQuestionIndex + 1) / quizQuestions.length) * 100;
  ui.progressBar.style.width = `${progressPercent}%`;
  ui.progressTrack.setAttribute('aria-valuenow', String(currentQuestionIndex + 1));

  ui.feedback.hidden = true;
  ui.feedback.className = 'game-feedback';
  ui.feedback.replaceChildren();

  ui.answerButtons.forEach((button) => {
    button.disabled = false;
    button.classList.remove('correct', 'wrong');
  });

  ui.nextButton.disabled = true;
  setText(ui.nextButton, currentQuestionIndex === quizQuestions.length - 1 ? 'LIHAT HASIL  →' : 'LANJUT  →');
}

function showFeedback(isCorrect, question) {
  const title = document.createElement('strong');
  title.className = 'feedback-title';
  title.textContent = isCorrect ? question.goodTitle : question.badTitle;

  const description = document.createElement('span');
  description.textContent = isCorrect ? question.goodText : question.badText;

  ui.feedback.replaceChildren(title, description);
  ui.feedback.className = `game-feedback ${isCorrect ? 'good' : 'bad'}`;
  ui.feedback.hidden = false;
}

function chooseAnswer(choiceIndex) {
  if (hasAnswered) return;

  const question = quizQuestions[currentQuestionIndex];
  if (!question || !Number.isInteger(choiceIndex)) return;

  hasAnswered = true;
  const isCorrect = choiceIndex === question.correct;
  if (isCorrect) totalScore += 1;

  ui.answerButtons.forEach((button, index) => {
    button.disabled = true;
    if (index === question.correct) button.classList.add('correct');
    if (index === choiceIndex && !isCorrect) button.classList.add('wrong');
  });

  showFeedback(isCorrect, question);
  setText(ui.score, `SKOR: ${totalScore}`);
  ui.nextButton.disabled = false;
}

function showResult() {
  ui.gamePlay.hidden = true;
  ui.gameResult.hidden = false;

  setText(ui.finalScore, `${totalScore}/${quizQuestions.length}`);

  if (totalScore === quizQuestions.length) {
    setText(ui.resultMedal, '🏆');
    setText(ui.resultTitle, 'Perfect choices!');
    setText(ui.resultMessage, 'Hebat! Kamu berhasil memilih semua kebiasaan yang lebih sehat. Terus jaga keseimbangan dalam menggunakan handphone.');
  } else if (totalScore >= 3) {
    setText(ui.resultMedal, '🌟');
    setText(ui.resultTitle, 'Good progress!');
    setText(ui.resultMessage, 'Pilihanmu sudah cukup baik. Pelajari kembali situasi yang terlewat dan terus latih kebiasaan digital yang sehat.');
  } else {
    setText(ui.resultMedal, '💡');
    setText(ui.resultTitle, 'Saatnya belajar!');
    setText(ui.resultMessage, 'Tidak apa-apa. Ini kesempatan untuk memahami pilihan yang lebih baik. Mulai dari satu perubahan kecil dan coba lagi!');
  }

  ui.progressBar.style.width = '100%';
  ui.progressTrack.setAttribute('aria-valuenow', String(quizQuestions.length));
}

function goToNextQuestion() {
  if (!hasAnswered) return;

  if (currentQuestionIndex < quizQuestions.length - 1) {
    currentQuestionIndex += 1;
    renderQuestion();
  } else {
    showResult();
  }
}

function restartGame() {
  currentQuestionIndex = 0;
  totalScore = 0;
  hasAnswered = false;
  renderQuestion();
  if (ui.gamePanel) {
    ui.gamePanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function setupNavigation() {
  if (!ui.menuToggle || !ui.nav) return;

  ui.menuToggle.addEventListener('click', () => {
    const isOpen = ui.nav.classList.toggle('open');
    ui.menuToggle.setAttribute('aria-expanded', String(isOpen));
    ui.menuToggle.setAttribute('aria-label', isOpen ? 'Tutup navigasi' : 'Buka navigasi');
  });

  ui.nav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      ui.nav.classList.remove('open');
      ui.menuToggle.setAttribute('aria-expanded', 'false');
      ui.menuToggle.setAttribute('aria-label', 'Buka navigasi');
    });
  });
}

function setupGame() {
  if (!ui.answerButtons.length || !ui.nextButton || !ui.restartButton) {
    console.error('Mini game tidak dapat dijalankan: tombol game tidak ditemukan.');
    return;
  }

  ui.answerButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const selectedChoice = Number(button.dataset.choice);
      chooseAnswer(selectedChoice);
    });
  });

  ui.nextButton.addEventListener('click', goToNextQuestion);
  ui.restartButton.addEventListener('click', restartGame);
  renderQuestion();
}

function initializeWebsite() {
  setText(ui.year, String(new Date().getFullYear()));
  setupNavigation();
  setupGame();
  console.info('IT\'S RED RED: website dan mini game berhasil dimuat.');
}

initializeWebsite();
