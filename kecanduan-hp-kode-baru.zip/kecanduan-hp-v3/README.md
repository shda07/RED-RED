# Kecanduan HP? It's Red Red!

Website edukasi tentang penggunaan handphone secara bijak. Paket ini dibuat dengan HTML, CSS, dan JavaScript murni, tanpa framework atau proses build.

## Isi folder

- `index.html` — seluruh struktur dan materi website.
- `style.css` — desain responsif untuk laptop dan HP.
- `script.js` — navigasi menu dan mini game interaktif.

## Cara mencoba di laptop

1. Ekstrak file ZIP.
2. Pastikan ketiga file berada di folder yang sama.
3. Buka `index.html` menggunakan browser (Chrome, Edge, atau Firefox).
4. Gulir ke bagian **Mini Game** dan coba jawab pertanyaannya.

## Cara memperbarui GitHub Pages

1. Buka repository GitHub kamu.
2. Masuk ke halaman utama repository (tab **Code**).
3. Pilih **Add file → Upload files**.
4. Upload ketiga file baru: `index.html`, `style.css`, dan `script.js`.
5. Pastikan nama file persis sama, huruf kecil semua, dan tidak berada di dalam folder tambahan.
6. Jika GitHub menampilkan pilihan mengganti file yang sudah ada, lanjutkan dengan mengganti file lama.
7. Klik **Commit changes**.
8. Pastikan GitHub Pages aktif melalui **Settings → Pages**, menggunakan branch `main` dan folder `/ (root)`.
9. Setelah publikasi selesai, buka website dan lakukan hard refresh: `Ctrl + F5` (Windows) atau `Cmd + Shift + R` (Mac).

## Penting

Baris pemanggil JavaScript sudah ada di `index.html`:

```html
<script src="./script.js" defer></script>
```

Karena itu, `script.js` harus berada sejajar dengan `index.html`, bukan di folder lain. Penulisan nama file di GitHub memperhatikan huruf besar/kecil.

Website ini merupakan materi edukasi, bukan alat diagnosis medis.
